/* Чөлөө — app logic. Amin narrates every step. */
(() => {
const PREVIEW = !!window.CHULUU_PREVIEW; // claude.ai artifact preview: no Netlify functions; Amin chat via Claude
const { RULES, VO, VOF, HABITS, QUIZ, ROADMAP, MILESTONES, QUOTES, COURSES, BLOCK, CRISIS, CRISIS_WORDS, PLANS } = window.C;
const $app = document.getElementById("app");
const KEY = "chuluu.v1";
const DAY = 86400000;
const FREE_CHATS = 5;
const TTS_V = "2"; // bump to regenerate cached narration

/* ---------- state ---------- */
const blank = () => ({
  onboarded: false, name: "", habits: [], answers: {}, score: 0,
  start: {}, best: {}, cleanTotal: {}, relapses: [], urges: [], journal: [],
  checkins: {}, lessonsDone: [], companion: null, plan: null, voice: true, ambient: true, autoplay: true,
  chat: [], chatDay: { d: "", n: 0 }, celebrated: {}, current: null, committedAt: null,
});
let S = load();
function load() {
  try { const raw = localStorage.getItem(KEY); if (raw) return Object.assign(blank(), JSON.parse(raw)); } catch (e) {}
  return blank();
}
function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }

/* ---------- helpers ---------- */
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const H = (id) => HABITS.find((h) => h.id === id) || HABITS[HABITS.length - 1];
const today = () => new Date().toISOString().slice(0, 10);
const fmtMNT = (n) => n.toLocaleString("en-US").replace(/,/g, "'") + "₮";
const pad = (n) => String(n).padStart(2, "0");
const q = (s, r = document) => r.querySelector(s);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const icon = (paths, size = 22) => `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths}</svg>`;
const I = {
  back: '<path d="M15 18l-6-6 6-6"/>', close: '<path d="M18 6L6 18M6 6l12 12"/>', check: '<path d="M5 12l5 5L20 7"/>',
  home: '<path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  chat: '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/>',
  book: '<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M4 19V5M8 7h7"/>',
  pen: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M14 6l4 4"/>', user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  bolt: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>', send: '<path d="M4 12l16-8-6 16-3-7z"/>',
  play: '<path d="M7 4.5v15l12-7.5z" fill="currentColor"/>', pause: '<path d="M8 5v14M16 5v14" stroke-width="3"/>',
  replay: '<path d="M4 12a8 8 0 1 0 2.3-5.7"/><path d="M4 4v4h4"/>',
  speaker: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12"/>',
  mute: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M17 9l5 6M22 9l-5 6"/>', music: '<path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>', heart: '<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/>',
  life: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/><path d="M5.6 5.6l3.6 3.6M14.8 14.8l3.6 3.6M18.4 5.6l-3.6 3.6M9.2 14.8l-3.6 3.6"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>', plus: '<path d="M12 5v14M5 12h14"/>',
  star: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>', chev: '<path d="M9 6l6 6-6 6"/>',
  fp: '<path d="M12 11v3M8.5 8.5A5 5 0 0 1 17 12v1M7 12a5 5 0 0 1 .3-1.7M7 15a14 14 0 0 0 1 4M12 17a20 20 0 0 1-.5 4M16.5 16a17 17 0 0 1-.6 4.5"/><path d="M5 9a8 8 0 0 1 14 0M19.5 13.5a19 19 0 0 1-.4 3.5"/>',
};
function toast(t) { const el = document.createElement("div"); el.className = "toast"; el.textContent = t; document.body.appendChild(el); setTimeout(() => el.remove(), 2600); }
function confetti() {
  const c = document.createElement("div"); c.className = "confetti";
  const cols = ["#F6B661", "#F2846A", "#8FE3D2", "#B9A6F5", "#F6F1E8"];
  for (let i = 0; i < 70; i++) { const p = document.createElement("i"); p.style.left = Math.random() * 100 + "%"; p.style.background = cols[i % cols.length]; p.style.animationDelay = Math.random() * 0.6 + "s"; p.style.animationDuration = 2 + Math.random() * 1.6 + "s"; c.appendChild(p); }
  document.body.appendChild(c); setTimeout(() => c.remove(), 4200);
}
const vibrate = (p) => { try { navigator.vibrate && navigator.vibrate(p); } catch (e) {} };

/* ==========================================================
   AUDIO — Amin's voice (ElevenLabs via /api/tts) + ambient pad
   WebAudio so iOS allows playback after the first tap.
   ========================================================== */
const AC = window.AudioContext || window.webkitAudioContext;
let ctx = null, voiceOut = null, analyser = null, amb = null, src = null;
function initAudio() {
  if (ctx || !AC) return;
  try {
    ctx = new AC();
    voiceOut = ctx.createGain(); voiceOut.gain.value = 1;
    analyser = ctx.createAnalyser(); analyser.fftSize = 512;
    voiceOut.connect(analyser); analyser.connect(ctx.destination);
  } catch (e) { ctx = null; }
}
function unlockAudio() {
  initAudio();
  try { if (ctx && ctx.state === "suspended") ctx.resume(); } catch (e) {}
  if (S.ambient && !amb) startAmbient();
}
document.addEventListener("pointerdown", unlockAudio, { passive: true });

// A soft, slowly breathing pad: three sine voices through a low-pass, with gentle LFOs.
function startAmbient() {
  if (!ctx || amb) return;
  try {
    const master = ctx.createGain(); master.gain.value = 0;
    const lp = ctx.createBiquadFilter(); lp.type = "lowpass"; lp.frequency.value = 820; lp.Q.value = 0.4;
    lp.connect(master); master.connect(ctx.destination);
    const notes = [110, 164.81, 220, 277.18];
    const oscs = notes.map((f, i) => {
      const o = ctx.createOscillator(); o.type = i === 3 ? "triangle" : "sine"; o.frequency.value = f; o.detune.value = (i % 2 ? 4 : -4);
      const g = ctx.createGain(); g.gain.value = i === 3 ? 0.10 : 0.22;
      const lfo = ctx.createOscillator(); lfo.frequency.value = 0.05 + i * 0.023;
      const lg = ctx.createGain(); lg.gain.value = g.gain.value * 0.6;
      lfo.connect(lg); lg.connect(g.gain); o.connect(g); g.connect(lp); o.start(); lfo.start();
      return [o, lfo];
    });
    master.gain.setTargetAtTime(0.055, ctx.currentTime, 2.5);
    amb = { master, oscs };
  } catch (e) { amb = null; }
}
function stopAmbient() {
  if (!amb) return;
  const a = amb; amb = null;
  try { a.master.gain.setTargetAtTime(0, ctx.currentTime, 0.4); setTimeout(() => a.oscs.forEach(([o, l]) => { o.stop(); l.stop(); }), 1500); } catch (e) {}
}
function duck(on) { if (amb && ctx) amb.master.gain.setTargetAtTime(on ? 0.02 : 0.055, ctx.currentTime, 0.35); }

const audioCache = new Map(), pending = new Map();
let voiceAvailable = !PREVIEW;
let speakToken = 0, speaking = false;
const ttsClean = (t) => t.replace(/\p{Extended_Pictographic}|️/gu, "").replace(/\s+/g, " ").trim();

function getVoice(text, cacheable) {
  if (audioCache.has(text)) return Promise.resolve(audioCache.get(text));
  if (pending.has(text)) return pending.get(text);
  const p = (async () => {
    const res = cacheable
      ? await fetch(`/api/tts?v=${TTS_V}&t=${encodeURIComponent(text)}`)
      : await fetch("/api/tts", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text }) });
    if (!res.ok) { if (res.status === 503) voiceAvailable = false; throw new Error("tts " + res.status); }
    const bytes = await res.arrayBuffer();
    initAudio();
    const buf = await new Promise((ok, bad) => ctx.decodeAudioData(bytes, ok, bad));
    audioCache.set(text, buf);
    return buf;
  })().finally(() => pending.delete(text));
  pending.set(text, p);
  return p;
}
// Small prefetch queue (2 at a time) so the next screen's narration is ready.
const pfQueue = []; let pfRunning = 0;
function prefetch(texts) {
  if (!S.voice || !voiceAvailable) return;
  texts.filter(Boolean).map(ttsClean).forEach((t) => { if (!audioCache.has(t) && !pending.has(t) && !pfQueue.includes(t)) pfQueue.push(t); });
  pump();
}
function pump() {
  while (pfRunning < 2 && pfQueue.length) {
    const t = pfQueue.shift(); pfRunning++;
    getVoice(t, true).catch(() => {}).finally(() => { pfRunning--; pump(); });
  }
}

function setLvl(v) { document.documentElement.style.setProperty("--lvl", v.toFixed(3)); }
function stopVoice() {
  speakToken++;
  try { src && src.stop(); } catch (e) {}
  src = null; speaking = false; setLvl(0); duck(false); npShow(false);
  document.querySelectorAll(".speaking").forEach((e) => e.classList.remove("speaking", "css"));
}

/* Now-playing bar for the main app */
const $np = document.getElementById("np");
q("#npPause").innerHTML = icon(I.close, 15);
q("#npPause").onclick = () => stopVoice();
function npShow(on) { $np.classList.toggle("show", !!on); }

/* speak(text, {capEl, orbEl, cacheable, np, onProgress}) → resolves true when finished, false when interrupted.
   Highlights caption words karaoke-style; drives --lvl from the real voice (audio-reactive orb). */
async function speak(rawText, { capEl, orbEl, cacheable = true, np = false, onProgress } = {}) {
  stopVoice();
  const my = ++speakToken;
  const text = ttsClean(rawText);
  const words = rawText.split(/\s+/).filter(Boolean);
  if (capEl) capEl.innerHTML = words.map((w) => `<span class="w">${esc(w)}</span>`).join(" ");
  const spans = capEl ? [...capEl.querySelectorAll(".w")] : [];
  // weight words by length so highlighting tracks speech more closely
  const cum = []; let tot = 0; words.forEach((w) => { tot += w.length + 2; cum.push(tot); });
  const light = (frac) => {
    const pos = frac * tot; let n = cum.findIndex((c) => c > pos); if (n < 0) n = spans.length;
    spans.forEach((s, i) => { s.classList.toggle("on", i <= n); s.classList.toggle("now", i === n); });
    onProgress && onProgress(Math.min(1, frac));
  };
  orbEl && orbEl.classList.add("speaking");
  speaking = true; if (np) npShow(true);
  let usedAudio = false;
  if (S.voice && voiceAvailable) {
    try {
      const buf = await getVoice(text, cacheable);
      if (my !== speakToken) return false;
      if (ctx.state === "suspended") await ctx.resume();
      if (ctx.state !== "running") throw new Error("audio locked");
      src = ctx.createBufferSource(); src.buffer = buf; src.connect(voiceOut);
      const t0 = ctx.currentTime; let ended = false; src.onended = () => (ended = true);
      duck(true); src.start(); usedAudio = true;
      const data = new Uint8Array(analyser.fftSize);
      await new Promise((resolve) => {
        const tick = () => {
          if (my !== speakToken || ended) return resolve();
          analyser.getByteTimeDomainData(data);
          let s = 0; for (let i = 0; i < data.length; i++) { const x = (data[i] - 128) / 128; s += x * x; }
          setLvl(Math.min(1, Math.sqrt(s / data.length) * 4.2));
          light((ctx.currentTime - t0) / buf.duration);
          requestAnimationFrame(tick);
        };
        tick();
      });
    } catch (e) { usedAudio = false; }
  }
  if (!usedAudio) {
    // captions-only fallback (voice not configured yet or muted)
    orbEl && orbEl.classList.add("css");
    const ms = Math.max(1400, text.length * 55); const t0 = performance.now();
    await new Promise((resolve) => {
      const tick = (t) => {
        if (my !== speakToken) return resolve();
        const f = (t - t0) / ms; setLvl(0.25 + 0.2 * Math.sin(t / 140)); light(f);
        if (f >= 1) return resolve(); requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    });
  }
  if (my !== speakToken) return false;
  light(1); spans.forEach((s) => s.classList.remove("now"));
  speaking = false; setLvl(0); duck(false); npShow(false);
  orbEl && orbEl.classList.remove("speaking", "css");
  return true;
}

/* ---------- time math ---------- */
const elapsed = (h) => (S.start[h] ? Date.now() - S.start[h] : 0);
const daysOf = (h) => Math.floor(elapsed(h) / DAY);
const nextMilestone = (d) => MILESTONES.find((m) => m > d) || d + 365;
const prevMilestone = (d) => [...MILESTONES].reverse().find((m) => m <= d) || 0;
const cleanTotalDays = (h) => Math.floor(((S.cleanTotal[h] || 0) + elapsed(h)) / DAY);
const bestDays = (h) => Math.floor(Math.max(S.best[h] || 0, elapsed(h)) / DAY);

/* ---------- score ---------- */
function quizList() { return QUIZ.filter((x) => !x.only || x.only.some((o) => S.habits.includes(o))); }
function computeScore() {
  let got = 0, max = 0;
  QUIZ.forEach((qq) => {
    if (qq.only && !qq.only.some((o) => S.habits.includes(o))) return;
    const a = S.answers[qq.id];
    if (qq.type === "one" && qq.opts[0][1] !== undefined) { max += Math.max(...qq.opts.map((o) => o[1])); if (a != null) got += qq.opts[a][1]; }
    else if (qq.scoreEach) { max += qq.opts.length * qq.scoreEach * 0.6; got += (a || []).length * qq.scoreEach; }
  });
  return Math.max(12, Math.min(96, Math.round((got / max) * 100)));
}
const level = (s) => s >= 62 ? ["Хүчтэй хамаарал", "#FF7A72"] : s >= 38 ? ["Дунд зэргийн хамаарал", "#F6B661"] : ["Эрт үе шат", "#8FE3D2"];
const needsAlcoholSafety = () => S.habits.includes("alcohol") && ((S.answers.morning ?? 9) <= 1 || ((S.answers.freq ?? 9) <= 1 && (S.answers.years ?? 9) <= 1));
const pickList = (id) => (S.answers[id] || []).map((i) => QUIZ.find((x) => x.id === id).opts[i][0]);
const goalText = () => (S.answers.goal != null ? QUIZ.find((x) => x.id === "goal").opts[S.answers.goal][0] : "");

/* ---------- narration per screen ---------- */
const FLOW = ["welcome", "privacy", "choose", "quizIntro", "quiz", "name", "calc", "result", "roadmap", "commit", "paywall", "companion", "blocker", "done"];
function lineFor(name, p = {}) {
  switch (name) {
    case "welcome": return VO.welcome; case "privacy": return VO.privacy; case "choose": return VO.choose;
    case "quizIntro": return VO.quiz; case "quiz": { const l = quizList(); return l[p.i || 0]?.q; }
    case "safety": return VO.safety; case "name": return VO.name; case "calc": return VO.calc;
    case "result": return VOF.result(S.name); case "roadmap": return VO.roadmap; case "commit": return VO.commit;
    case "paywall": return VO.paywall; case "companion": return VO.companion; case "blocker": return VO.blocker;
    case "done": return VOF.done(S.name);
  }
  return null;
}
function upcoming(name, p = {}) {
  if (name === "quiz") { const l = quizList(); const i = p.i || 0; return [l[i + 1]?.q, l[i + 2]?.q, i + 1 >= l.length - 1 ? VO.name : null]; }
  if (name === "quizIntro") return [lineFor("quiz", { i: 0 }), lineFor("quiz", { i: 1 })];
  const i = FLOW.indexOf(name); if (i < 0) return [];
  return [FLOW[i + 1], FLOW[i + 2]].filter((n) => n && n !== "quiz").map((n) => lineFor(n)).concat(FLOW[i + 1] === "quiz" ? [lineFor("quiz", { i: 0 })] : []);
}
// Aurora tint per onboarding step
const TINTS = [["#F6B661", "#B9A6F5", "#8FE3D2"], ["#F2846A", "#B9A6F5", "#F6B661"], ["#B9A6F5", "#8FE3D2", "#F6B661"], ["#8FE3D2", "#B9A6F5", "#F2846A"]];
function tint(k) { const t = TINTS[k % TINTS.length]; const r = document.documentElement.style; r.setProperty("--a1", t[0]); r.setProperty("--a2", t[1]); r.setProperty("--a3", t[2]); }

/* ---------- router ---------- */
let route = { name: S.onboarded ? "home" : "splash", p: {} };
let ticker = null;
function go(name, p = {}) { stopVoice(); closeSheet(); route = { name, p }; render(); window.scrollTo(0, 0); }
function render() {
  clearInterval(ticker);
  const fn = SCREENS[route.name];
  $app.innerHTML = fn ? fn(route.p) : "";
  const fi = FLOW.indexOf(route.name); tint(fi >= 0 ? Math.floor(fi / 3) : 0);
  const after = AFTER[route.name]; after && after(route.p);
  const line = lineFor(route.name, route.p);
  if (line && !NO_AUTO.has(route.name)) narrate(line);
  prefetch(upcoming(route.name, route.p));
}
const NO_AUTO = new Set(["commit_none"]);
function narrate(line) { const cap = q("#cap"), orb = q("#orb"); speak(line, { capEl: cap, orbEl: orb }); }

const prog = (cur) => { const n = 7, i = Math.min(n, Math.ceil(((FLOW.indexOf(cur) + 1) / FLOW.length) * n)); return `<div class="progress">${[...Array(n)].map((_, k) => `<i class="${k < i ? "on" : ""}"></i>`).join("")}</div>`; };
const topbar = (cur, back = true) => `<div class="top">${back ? `<button class="iconbtn" data-back aria-label="Буцах">${icon(I.back)}</button>` : `<div style="width:42px"></div>`}${prog(cur)}<button class="iconbtn" data-sound aria-label="Дуу">${icon(S.voice ? I.speaker : I.mute, 19)}</button></div>`;
const bigOrb = () => `<div class="orb-wrap" id="orb"><div class="orb-glow"></div><div class="orb-ring"></div><div class="orb-ring r2"></div><div class="orb"></div></div>`;
const replayBtn = () => `<button class="listen" data-replay>${icon(I.replay, 16)} Дахин сонсох</button>`;
const miniAmin = () => `<div class="row" style="margin-top:22px;gap:12px;align-items:flex-start"><div class="orb-mini" id="orb"></div><div class="caption sm left" id="cap" style="flex:1;min-height:48px"></div><button class="iconbtn" data-replay aria-label="Дахин сонсох" style="width:36px;height:36px">${icon(I.replay, 16)}</button></div>`;

const SCREENS = {
  splash: () => `<div class="splash"><div><div class="orb-wrap" style="width:170px;height:170px"><div class="orb-glow"></div><div class="orb" style="width:104px;height:104px"></div></div>
    <div class="logo">Чөлөө<em>.</em></div><p class="lead" style="margin-top:4px">Амин тантай хамт</p></div></div>`,

  intro: () => `<div class="screen"><div class="grow"></div>
    <div class="center">${bigOrb()}<div class="logo">Чөлөө<em>.</em></div>
    <p class="lead" style="max-width:330px;margin-inline:auto">Архи, порно, тоглоом, бооцоо, тамхи. Ямар ч зуршлаас ангижрах таны хувийн AI дасгалжуулагч.</p></div>
    <div class="grow"></div>
    <div class="stack"><button class="btn" data-go="welcome">${icon(I.play, 16)} Аминтай танилцах</button>
    <p class="small center">🎧 Амин таныг бүх замд дуу хоолойгоороо хөтөлнө</p></div></div>`,

  welcome: () => `<div class="screen">${topbar("welcome", false)}<div class="grow"></div>${bigOrb()}
    <div class="caption" id="cap"></div><div class="center">${replayBtn()}</div><div class="grow"></div>
    <button class="btn" data-next="welcome">Үргэлжлүүлэх</button></div>`,

  privacy: () => `<div class="screen">${topbar("privacy")}${miniAmin()}
    <h1 style="margin-top:26px">Энд та аюулгүй</h1>
    <div class="stack" style="margin-top:20px">
      ${[[I.shield, "100% нууцлал", "Бүртгэл, нэр, утас шаардахгүй. Мэдээлэл зөвхөн таны төхөөрөмжид.", "#8FE3D2"],
         [I.heart, "Шүүмжлэлгүй дэмжлэг", "Амин 24/7 тантай. Бүдэрсэн ч ичих хэрэггүй.", "#F2846A"],
         [I.book, "Шинжлэх ухаанд суурилсан", "CBT, сэдэл нэмэгдүүлэх арга, хүслийн давалгааг даван туулах дасгал.", "#B9A6F5"]]
        .map(([ic, t, s, c], k) => `<div class="opt" style="animation-delay:${k * 80}ms;cursor:default"><span class="ic" style="background:${c}22;color:${c}">${icon(ic)}</span><span><h3>${t}</h3><span class="small" style="display:block;margin-top:3px;font-weight:500">${s}</span></span></div>`).join("")}
    </div><div class="grow"></div><div class="spacer"></div>
    <button class="btn" data-next="privacy">Ойлголоо</button></div>`,

  choose: () => `<div class="screen">${topbar("choose")}${miniAmin()}
    <h1 style="margin-top:22px">Юунаас ангижрах вэ?</h1>
    <div class="stack" style="margin-top:18px">
      ${HABITS.map((h, k) => `<button class="opt ${S.habits.includes(h.id) ? "on" : ""}" data-habit="${h.id}" style="animation-delay:${k * 45}ms">
        <span class="ic" style="background:${h.hue}22;color:${h.hue}">${icon(h.icon)}</span>${h.label}<span class="chk"></span></button>`).join("")}
    </div><div class="spacer"></div>
    <button class="btn" data-next="choose" ${S.habits.length ? "" : "disabled"}>Үргэлжлүүлэх</button></div>`,

  quizIntro: () => `<div class="screen">${topbar("quizIntro")}<div class="grow"></div>${bigOrb()}
    <div class="caption" id="cap"></div><div class="center">${replayBtn()}</div><div class="grow"></div>
    <button class="btn" data-go="quiz">Эхлэх</button></div>`,

  quiz: ({ i = 0 }) => {
    const list = quizList(); const qq = list[i]; const a = S.answers[qq.id]; const multi = qq.type === "multi";
    return `<div class="screen"><div class="top"><button class="iconbtn" data-qback="${i}" aria-label="Буцах">${icon(I.back)}</button>
      <div class="progress">${list.map((_, k) => `<i class="${k <= i ? "on" : ""}"></i>`).join("")}</div>
      <button class="iconbtn" data-sound aria-label="Дуу">${icon(S.voice ? I.speaker : I.mute, 19)}</button></div>
      <div class="row" style="margin-top:22px;gap:10px"><div class="orb-mini" id="orb" style="width:30px;height:30px"></div><span class="small" style="font-weight:800">Асуулт ${i + 1} / ${list.length}</span></div>
      <h2 id="cap" style="margin-top:14px;font-weight:300">${esc(qq.q)}</h2>${qq.sub ? `<p class="small" style="margin-top:8px">${qq.sub}</p>` : ""}
      <div class="stack" style="margin-top:20px">
        ${qq.opts.map((o, k) => { const on = multi ? (a || []).includes(k) : a === k;
          return `<button class="opt ${on ? "on" : ""}" data-ans="${k}" data-q="${i}" style="animation-delay:${k * 50}ms">${esc(o[0])}<span class="chk"></span></button>`; }).join("")}
      </div><div class="grow"></div><div class="spacer"></div>
      ${multi ? `<button class="btn" data-qnext="${i}" ${(a || []).length ? "" : "disabled"}>Үргэлжлүүлэх</button>` : ""}
      ${qq.safety ? `<p class="small center" style="margin-top:10px">Энэ асуулт таны аюулгүй байдлын төлөө.</p>` : ""}</div>`;
  },

  safety: () => `<div class="screen">${topbar("quiz")}${miniAmin()}
    <div class="grow"></div><div class="card crisis" style="padding:22px">
      <div class="row" style="color:var(--rose)">${icon(I.life, 26)}<h2 style="color:var(--ink)">Эхлээд аюулгүй байдал</h2></div>
      <p style="margin:14px 0 0">Удаан хугацаанд өдөр бүр, их хэмжээгээр уусан хүн <b>гэнэт зогсоох нь аюултай</b> байж болно: гар чичрэх, хөлрөх, таталт, дэмийрэл үүсч болзошгүй.</p>
      <p style="margin:12px 0 0">Тиймээс архиа болихоос өмнө <b>эмчтэй зөвлөлдөөрэй</b>. Эмчийн хяналтан дор болих нь илүү аюулгүй, амжилттай.</p>
      <div style="margin-top:14px">${CRISIS.slice(0, 2).map((c) => `<a class="tel" href="tel:${c.n.replace(/-/g, "")}"><b>${c.n}</b><span class="small">${c.t}</span></a>`).join("")}</div>
    </div><div class="grow"></div><div class="spacer"></div>
    <button class="btn" data-go="name">Ойлголоо, үргэлжлүүлэх</button></div>`,

  name: () => `<div class="screen">${topbar("name")}${miniAmin()}
    <h1 style="margin-top:26px">Таны нэр</h1>
    <input class="field" id="nm" style="margin-top:18px" maxlength="24" placeholder="Жишээ: Бат" value="${esc(S.name)}" autocomplete="off">
    <p class="small" style="margin-top:10px">Зөвхөн Амин таныг ингэж дуудна. Хэнд ч харагдахгүй.</p>
    <div class="grow"></div><button class="btn" id="nmGo" ${S.name ? "" : "disabled"}>Үргэлжлүүлэх</button></div>`,

  calc: () => `<div class="screen"><div class="grow"></div>${bigOrb()}
    <div class="caption sm" id="cap"></div>
    <div class="stack" style="margin:10px auto 0;width:100%;max-width:320px" id="steps">
      ${["Хариултуудыг шинжилж байна", "Өдөөгчдийг тодорхойлж байна", "90 хоногийн хөтөлбөр гаргаж байна"].map((t, k) =>
        `<div class="row small" data-step="${k}" style="opacity:.25;transition:opacity .5s"><span style="color:var(--ok)">${icon(I.check, 18)}</span>${t}</div>`).join("")}
    </div><div class="grow"></div></div>`,

  result: () => {
    const s = S.score; const [lv, col] = level(s); const trig = pickList("triggers"), imp = pickList("impact");
    const arc = 251.3; const off = arc * (1 - s / 100);
    return `<div class="screen">${topbar("result")}
      <div class="center" style="margin-top:16px"><div class="eyebrow">Өөрийгөө үнэлэх</div><h1 style="margin-top:8px">${esc(S.name)}, таны үр дүн</h1></div>
      <div class="gauge"><svg viewBox="0 0 200 110"><defs><linearGradient id="gg" x1="0" x2="1"><stop offset="0" stop-color="#8FE3D2"/><stop offset=".55" stop-color="#F6B661"/><stop offset="1" stop-color="#FF7A72"/></linearGradient></defs>
        <path d="M20 100 A80 80 0 0 1 180 100" fill="none" stroke="rgba(255,255,255,.08)" stroke-width="12" stroke-linecap="round"/>
        <path id="garc" d="M20 100 A80 80 0 0 1 180 100" fill="none" stroke="url(#gg)" stroke-width="12" stroke-linecap="round" stroke-dasharray="${arc}" stroke-dashoffset="${arc}" style="transition:stroke-dashoffset 1.6s var(--ease)" data-off="${off}"/></svg>
        <div class="val"><b id="gnum">0</b><span class="small">хамаарлын индекс / 100</span></div></div>
      <div class="center" style="margin-top:12px"><span class="tag" style="background:${col}22;color:${col}">${lv}</span></div>
      <div class="row" style="margin-top:16px;gap:10px;align-items:flex-start"><div class="orb-mini" id="orb" style="width:30px;height:30px"></div><div class="caption sm left" id="cap" style="flex:1"></div></div>
      <div class="stack" style="margin-top:8px">
        ${trig.length ? `<div class="card"><h3>Таны гол өдөөгчид</h3><div class="chips" style="margin-top:10px">${trig.map((t) => `<span class="chip">${esc(t)}</span>`).join("")}</div></div>` : ""}
        ${imp.length ? `<div class="card"><h3>Нөлөөлж буй хүрээ</h3><div class="chips" style="margin-top:10px">${imp.map((t) => `<span class="chip">${esc(t)}</span>`).join("")}</div></div>` : ""}
        <p class="small center">Энэ бол эмнэлгийн онош биш, зөвхөн өөрийгөө ойлгох хэрэгсэл.</p>
      </div><div class="spacer"></div>
      <button class="btn" data-next="result">Миний замыг харах</button></div>`;
  },

  roadmap: () => `<div class="screen">${topbar("roadmap")}${miniAmin()}
    <div style="margin-top:20px"><div class="eyebrow">Таны 90 хоног</div><h1 style="margin-top:8px">Тархи тань эдгэрнэ</h1></div>
    <div class="road" style="margin-top:22px">${ROADMAP.map((r, k) => `<div class="st" style="animation-delay:${k * 90}ms"><div class="d">${r.d}-р өдөр</div><h3 style="margin-top:3px">${r.t}</h3><div class="small">${r.s}</div></div>`).join("")}</div>
    <div class="grow"></div><button class="btn" data-next="roadmap">Би бэлэн</button></div>`,

  commit: () => `<div class="screen">${topbar("commit")}
    <div class="center" style="margin-top:22px"><div class="eyebrow">Амлалт</div>
    <h2 style="margin-top:12px;font-weight:300">“Би, ${esc(S.name)}, өнөөдрөөс эхлэн ${esc(S.habits.map((h) => H(h).from).join(", "))} ангижирч, өөртөө илүү сайн хандахаа амлаж байна.”</h2></div>
    <div class="hold" id="hold"><svg class="ring" viewBox="0 0 100 100"><circle cx="50" cy="50" r="46" fill="none" stroke="rgba(255,255,255,.08)" stroke-width="3"/>
      <circle id="hring" cx="50" cy="50" r="46" fill="none" stroke="#F6B661" stroke-width="3.5" stroke-linecap="round" stroke-dasharray="289" stroke-dashoffset="289"/></svg>
      <div class="fp">${icon(I.fp, 66)}</div></div>
    <p class="center small" id="holdtxt">Дарж байгаад 3 секунд барина уу</p>
    <div class="row" style="margin-top:14px;gap:10px;align-items:flex-start"><div class="orb-mini" id="orb" style="width:30px;height:30px"></div><div class="caption sm left" id="cap" style="flex:1"></div></div>
    <div class="grow"></div></div>`,

  paywall: () => {
    const sel = route.p.plan || "m1";
    return `<div class="screen" style="padding-top:calc(10px + var(--safe-t))">
      <div class="top"><button class="iconbtn" data-skip-pay aria-label="Хаах">${icon(I.close, 20)}</button><div class="grow"></div><button class="iconbtn" data-sound aria-label="Дуу">${icon(S.voice ? I.speaker : I.mute, 19)}</button></div>
      <div class="center"><div class="orb-wrap" id="orb" style="width:130px;height:130px;margin:0 auto 6px"><div class="orb-glow"></div><div class="orb-ring"></div><div class="orb" style="width:78px;height:78px"></div></div>
      <h1>${esc(S.name)}, таны хөтөлбөр бэлэн</h1></div>
      <div class="caption sm" id="cap" style="min-height:46px;margin-top:8px"></div>
      <div class="stack" style="margin-top:12px">
        ${["Амин AI дасгалжуулагчтай хязгааргүй ярих, дуу хоолойтой", "Бүх хичээл, дасгал, тархины сэргэлтийн хөтөлбөр", "Итгэлт хүнтэй холбогдох, ахиц хуваалцах", "Олон зуршлыг зэрэг хянах"]
          .map((t) => `<div class="feat"><span class="ck">${icon(I.check, 13)}</span><span>${t}</span></div>`).join("")}
      </div>
      <div class="stack" style="margin-top:22px;gap:12px">
        ${PLANS.map((p) => `<button class="plan ${p.id === sel ? "on" : ""}" data-plan="${p.id}">${p.tag ? `<span class="badge">${p.tag}</span>` : ""}
          <span class="radio"></span><span><b>${p.t}</b><br><span class="small">${p.per}</span></span><span class="pr"><b>${fmtMNT(p.p)}</b></span></button>`).join("")}
      </div>
      <p class="small center" style="margin-top:12px">Эхний 3 хоног үнэгүй. Хүссэн үедээ цуцална.</p>
      <div class="spacer"></div>
      <button class="btn" data-pay="${sel}">3 хоног үнэгүй эхлэх</button>
      <p class="small center" style="margin-top:12px">Яаралтай тусламж, тоолуур, амьсгалын дасгал үргэлж <b>үнэгүй</b>.</p></div>`;
  },

  companion: () => `<div class="screen">${topbar("companion")}${miniAmin()}
    <div style="margin-top:20px"><div class="eyebrow">Итгэлт хүн</div><h1 style="margin-top:8px">Таныг дэмжих нэг хүн</h1></div>
    <div class="stack" style="margin-top:22px">
      <input class="field" id="cn" placeholder="Нэр" maxlength="30" value="${esc(S.companion?.name || "")}">
      <input class="field" id="cp" placeholder="Утасны дугаар" inputmode="tel" maxlength="20" value="${esc(S.companion?.phone || "")}">
    </div>
    <p class="small" style="margin-top:10px">Дугаар зөвхөн таны утсанд хадгалагдана. Апп хэнд ч автоматаар мессеж илгээхгүй.</p>
    <div class="grow"></div>
    <div class="stack"><button class="btn" id="cSave">Хадгалах</button><button class="btn link" data-next="companion">Дараа нэмье</button></div></div>`,

  blocker: ({ tab }) => {
    const hs = S.habits.filter((h) => BLOCK[h]); const cur = tab || hs[0] || "other"; const b = BLOCK[cur];
    return `<div class="screen">${topbar("blocker")}${miniAmin()}
      <div style="margin-top:20px"><div class="eyebrow">Хамгаалалт</div><h1 style="margin-top:8px">Орчноо аюулгүй болгоё</h1></div>
      ${hs.length > 1 ? `<div class="habit-tabs">${hs.map((h) => `<button class="chip ${h === cur ? "on" : ""}" data-btab="${h}">${H(h).label}</button>`).join("")}</div>` : ""}
      <div class="card" style="margin-top:16px"><h3>${b.t}</h3>
        ${b.steps.map(([k, v]) => `<div style="margin-top:14px"><div class="eyebrow" style="color:var(--mint)">${k}</div><div style="margin-top:4px;font-size:15px">${esc(v)}</div></div>`).join("")}
      </div>
      <p class="small" style="margin-top:12px">Нууц кодыг итгэлт хүндээ тохируулуулбал хамгаалалт хамгийн хүчтэй болно. Энэ заавар Профайл хэсэгт үргэлж байна.</p>
      <div class="grow"></div><div class="spacer"></div>
      <button class="btn" data-next="blocker">Тоолуурыг эхлүүлэх</button></div>`;
  },

  done: () => `<div class="screen"><div class="grow"></div>${bigOrb()}
    <div class="center"><div class="eyebrow">Тоолуур эхэллээ</div><h1 style="margin-top:8px;font-variant-numeric:tabular-nums" id="dclock">00:00:00</h1></div>
    <div class="caption" id="cap" style="margin-top:14px"></div><div class="grow"></div>
    <button class="btn" id="enter">Нүүр хуудас руу</button></div>`,

  /* ---------- main app ---------- */
  home: () => {
    if (!S.current || !S.habits.includes(S.current)) S.current = S.habits[0];
    const h = S.current, hb = H(h); const d = daysOf(h);
    const nm = nextMilestone(d), pm = prevMilestone(d);
    const frac = Math.min(1, (elapsed(h) / DAY - pm) / (nm - pm));
    const C = 2 * Math.PI * 116;
    const mood = S.checkins[today()]?.mood; const lesson = nextLesson();
    const resisted = S.urges.filter((u) => u.resisted).length;
    const hr = new Date().getHours(); const greet = hr < 11 ? "Өглөөний мэнд" : hr < 18 ? "Сайн байна уу" : "Оройн мэнд";
    return `<div class="screen tabbed">
      <div class="top"><div class="grow"><div class="small">${greet},</div><h2 style="font-size:22px">${esc(S.name)}</h2></div>
        <button class="iconbtn" data-tab="amin" aria-label="Амин" style="padding:0;overflow:hidden;border:0"><span class="orb-mini" style="width:42px;height:42px"></span></button></div>
      ${S.habits.length > 1 ? `<div class="habit-tabs">${S.habits.map((x) => `<button class="chip ${x === h ? "on" : ""}" data-cur="${x}">${H(x).label} · ${daysOf(x)}ө</button>`).join("")}</div>` : ""}
      <div class="hero"><div class="sun">
        <svg viewBox="0 0 250 250"><defs><linearGradient id="g1" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stop-color="#FFD08A"/><stop offset=".6" stop-color="#F2846A"/><stop offset="1" stop-color="${hb.hue}"/></linearGradient></defs>
          <circle cx="125" cy="125" r="116" fill="none" stroke="rgba(255,255,255,.07)" stroke-width="6"/>
          <circle cx="125" cy="125" r="116" fill="none" stroke="url(#g1)" stroke-width="6" stroke-linecap="round" stroke-dasharray="${C}" stroke-dashoffset="${C * (1 - frac)}" style="filter:drop-shadow(0 0 8px rgba(246,182,97,.6))"/></svg>
        <div class="core"></div>
        <div class="inner"><div class="days" id="cdays">${d}</div><div class="unit">өдөр ${esc(hb.from)} ангид</div><div class="clock" id="cclock">00:00:00</div></div></div>
        <div class="small" style="margin-top:6px">Дараагийн босго <b style="color:var(--ink)">${nm} өдөр</b> · ${Math.max(0, nm - d)} өдөр үлдлээ</div></div>
      <div class="track">${MILESTONES.map((m) => `<div class="ms ${d >= m ? "done" : m === nm ? "next" : ""}"><b>${m}</b><span>өдөр</span></div>`).join("")}</div>
      <button class="card voicecard" style="margin-top:14px" data-daily><span class="play" id="dplay">${icon(I.play, 18)}</span>
        <span class="grow"><span class="eyebrow">Аминаас өнөөдрийн үг</span><span id="dcap" style="display:block;margin-top:6px;font-family:var(--display);font-weight:300;font-size:16px;line-height:1.45">${esc(QUOTES[new Date().getDate() % QUOTES.length])}</span></span></button>
      <div class="stats" style="margin-top:10px">
        <div class="stat"><b>${bestDays(h)}</b><span>Дээд амжилт</span></div>
        <div class="stat"><b>${resisted}</b><span>Ялсан хүсэл</span></div>
        <div class="stat"><b>${cleanTotalDays(h)}</b><span>Нийт өдөр</span></div>
      </div>
      <div class="card" style="margin-top:10px"><h3>${mood != null ? "Өнөөдрийн мэдрэмж хадгалагдлаа" : "Өнөөдөр ямар байна?"}</h3>
        <div class="moods">${["😣", "😔", "😐", "🙂", "😄"].map((m, k) => `<button class="mood ${mood === k ? "on" : ""}" data-mood="${k}" aria-label="${k + 1}">${m}</button>`).join("")}</div></div>
      ${lesson ? `<button class="card lesson-card" style="margin-top:10px" data-lesson="${lesson.c.id}:${lesson.l.id}">
        <div class="num" style="background:${lesson.c.color}22;color:${lesson.c.color}">${icon(I.play, 18)}</div>
        <div class="grow"><div class="small">Өнөөдрийн хичээл · ${lesson.l.min} мин · Амин уншина</div><h3 style="margin-top:3px">${esc(lesson.l.t)}</h3></div><span class="chev">${icon(I.chev, 18)}</span></button>` : ""}
      ${reasonsCard()}
      <button class="btn link" data-relapse style="margin-top:6px">Би бүдэрчихлээ</button>
    </div>${nav("home")}${panicFab()}`;
  },

  amin: () => {
    const msgs = S.chat.length ? S.chat : [{ role: "assistant", content: greeting() }];
    return `<div class="screen tabbed" style="padding-bottom:calc(230px + var(--safe-b))">
      <div class="top"><div class="orb-mini" id="aorb"></div><div class="grow"><h3>Амин</h3><div class="small">Таны дасгалжуулагч · 24/7</div></div>
        <button class="iconbtn" data-autoplay aria-label="Хариултыг чангаар унших" title="Хариултыг чангаар унших">${icon(S.autoplay && S.voice ? I.speaker : I.mute, 19)}</button></div>
      <div class="chat" id="chat" style="margin-top:14px">${msgs.map(msgHTML).join("")}</div>
      ${S.chat.length < 2 ? `<div class="chips" style="margin-top:14px">${["Яг одоо хүсэл хүчтэй байна", "Би бүдэрчихлээ", "Ганцаардаж байна", "Шөнө унтаж чадахгүй байна", "Яаж эхлэх вэ?"].map((t) => `<button class="chip" data-quick="${esc(t)}">${t}</button>`).join("")}</div>` : ""}
    </div>
    <form class="composer" id="cform"><input id="cin" placeholder="Аминд бичих…" autocomplete="off" maxlength="1200" aria-label="Мессеж"><button aria-label="Илгээх">${icon(I.send)}</button></form>
    ${nav("amin")}`;
  },

  learn: () => `<div class="screen tabbed"><div class="top"><h2 class="grow">Хичээл</h2></div>
    <p class="small" style="margin-top:2px">5 минутын богино хичээлүүд. Амин уншиж, хуудас өөрөө эргэнэ.</p>
    ${COURSES.map((c, ci) => {
      const done = c.lessons.filter((l) => S.lessonsDone.includes(l.id)).length; const locked = ci > 0 && !hasPlan();
      return `<div class="card" style="margin-top:14px"><div class="row"><div class="grow"><div class="eyebrow" style="color:${c.color}">${c.sub}</div><h3 style="margin-top:4px;font-family:var(--display);font-weight:400;font-size:18px">${c.title}</h3></div>
        <span class="small" style="font-variant-numeric:tabular-nums">${done}/${c.lessons.length}</span></div>
        <div class="progress" style="margin-top:12px">${c.lessons.map((l) => `<i class="${S.lessonsDone.includes(l.id) ? "on" : ""}"></i>`).join("")}</div>
        <div style="margin-top:6px">${c.lessons.map((l, li) => `<button class="list-item" data-lesson="${c.id}:${l.id}">
          <span class="li-ic" style="color:${S.lessonsDone.includes(l.id) ? "var(--ok)" : c.color}">${S.lessonsDone.includes(l.id) ? icon(I.check, 18) : `<b style="font-family:var(--display);font-weight:400;font-size:14px">${li + 1}</b>`}</span>
          <span><span style="font-weight:700">${esc(l.t)}</span><br><span class="small">${l.min} минут · аудио</span></span>
          <span class="chev">${locked ? `<span class="lock">${icon(I.lock, 18)}</span>` : icon(I.play, 16)}</span></button>`).join("")}</div></div>`;
    }).join("")}
  </div>${nav("learn")}${panicFab()}`,

  journal: () => {
    const days = [...Array(14)].map((_, k) => { const d = new Date(Date.now() - (13 - k) * DAY).toISOString().slice(0, 10);
      return { d, w: S.urges.filter((u) => u.resisted && new Date(u.ts).toISOString().slice(0, 10) === d).length, r: S.relapses.filter((r) => new Date(r.ts).toISOString().slice(0, 10) === d).length }; });
    const mx = Math.max(3, ...days.map((x) => x.w + x.r));
    return `<div class="screen tabbed"><div class="top"><h2 class="grow">Тэмдэглэл</h2><button class="btn sm" data-newnote>${icon(I.plus, 18)} Бичих</button></div>
      <div class="card" style="margin-top:14px"><h3>Сүүлийн 14 хоног</h3>
        <div class="bars">${days.map((x) => `<div title="${x.d}"><i style="height:${(x.w / mx) * 100}%;background:var(--mint)"></i><i style="height:${(x.r / mx) * 100}%;background:var(--rose)"></i></div>`).join("")}</div>
        <div class="row small" style="margin-top:10px;gap:16px"><span><i style="display:inline-block;width:10px;height:10px;border-radius:3px;background:var(--mint)"></i> Ялсан хүсэл</span><span><i style="display:inline-block;width:10px;height:10px;border-radius:3px;background:var(--rose)"></i> Бүдрэл</span></div></div>
      <div class="stack" style="margin-top:12px">
        ${S.journal.length ? [...S.journal].reverse().map((j) => `<div class="card"><div class="row small"><span>${["😣", "😔", "😐", "🙂", "😄"][j.mood ?? 2]}</span><span>${new Date(j.ts).toLocaleString("mn-MN", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}</span>${j.tag ? `<span class="chip" style="padding:3px 9px;font-size:12px">${esc(j.tag)}</span>` : ""}</div>
          ${j.q ? `<div class="small" style="margin-top:8px;color:var(--sun)">${esc(j.q)}</div>` : ""}<div style="margin-top:6px;white-space:pre-wrap">${esc(j.text)}</div></div>`).join("")
        : `<div class="card center"><p class="small" style="margin:0">Бичих нь толгойгоо цэгцлэх хамгийн энгийн арга. Өнөөдрийн мэдрэмжээ хоёр өгүүлбэрээр бичээд үзээрэй.</p></div>`}
      </div></div>${nav("journal")}${panicFab()}`;
  },

  me: () => `<div class="screen tabbed"><div class="top"><h2 class="grow">${esc(S.name)}</h2></div>
    <div class="card" style="margin-top:14px;${hasPlan() ? "" : "background:linear-gradient(120deg,rgba(246,182,97,.18),rgba(242,132,106,.08))"}">
      ${hasPlan() ? `<div class="row"><span style="color:var(--sun)">${icon(I.star)}</span><div class="grow"><h3>Чөлөө Pro</h3><div class="small">${planLabel()}</div></div></div>`
      : `<h3>Чөлөө Pro</h3><p class="small" style="margin:6px 0 12px">Аминтай хязгааргүй ярих, бүх хичээл, олон зуршил.</p><button class="btn sm" data-go="paywall">Pro болох</button>`}</div>
    <div class="card" style="margin-top:12px;padding:4px 18px">
      <div class="list-item"><span class="li-ic">${icon(S.voice ? I.speaker : I.mute)}</span><span class="grow"><b>Аминий дуу хоолой</b>${!voiceAvailable ? `<br><span class="small">Удахгүй идэвхжинэ</span>` : ""}</span><button class="switch ${S.voice ? "on" : ""}" data-voice aria-label="Аминий дуу хоолой"></button></div>
      <div class="list-item"><span class="li-ic">${icon(I.music)}</span><span class="grow"><b>Тайван хөгжим</b><br><span class="small">Амин ярих үед зөөлөн дуу</span></span><button class="switch ${S.ambient ? "on" : ""}" data-ambient aria-label="Тайван хөгжим"></button></div>
      <div class="list-item"><span class="li-ic">${icon(I.chat)}</span><span class="grow"><b>Хариултыг чангаар унших</b></span><button class="switch ${S.autoplay ? "on" : ""}" data-autoplay-sw aria-label="Хариултыг чангаар унших"></button></div>
    </div>
    <div class="card" style="margin-top:12px;padding:4px 18px">
      <button class="list-item" data-sheet="habits"><span class="li-ic">${icon(I.bolt)}</span><span><b>Миний зуршлууд</b><br><span class="small">${S.habits.map((h) => H(h).label).join(", ")}</span></span><span class="chev">${icon(I.chev, 18)}</span></button>
      <button class="list-item" data-sheet="companion"><span class="li-ic">${icon(I.heart)}</span><span><b>Итгэлт хүн</b><br><span class="small">${S.companion ? esc(S.companion.name) : "Нэмээгүй"}</span></span><span class="chev">${icon(I.chev, 18)}</span></button>
      <button class="list-item" data-sheet="block"><span class="li-ic">${icon(I.shield)}</span><span><b>Хаах заавар</b><br><span class="small">Сайт, апп, гүйлгээ хязгаарлах</span></span><span class="chev">${icon(I.chev, 18)}</span></button>
      <button class="list-item" data-sheet="crisis"><span class="li-ic" style="color:var(--rose)">${icon(I.life)}</span><span><b>Яаралтай тусламжийн утас</b><br><span class="small">1800-2000 · 103</span></span><span class="chev">${icon(I.chev, 18)}</span></button>
    </div>
    <div class="card" style="margin-top:12px"><p class="small" style="margin:0">Чөлөө нь эмнэлгийн тусламжийг орлохгүй. Амин бол AI дасгалжуулагч, эмч биш. Архи, мансууруулах бодисоос гарахдаа эмчтэй зөвлөлдөөрэй.</p></div>
    <button class="btn link" data-wipe style="margin-top:8px;color:var(--rose)">${icon(I.trash, 18)} Бүх мэдээллийг устгах</button>
  </div>${nav("me")}${panicFab()}`,
};

/* ---------- partials ---------- */
function nav(cur) {
  const t = [["home", "Нүүр", I.home], ["amin", "Амин", I.chat], ["learn", "Хичээл", I.book], ["journal", "Тэмдэглэл", I.pen], ["me", "Би", I.user]];
  return `<nav class="nav">${t.map(([k, l, ic]) => `<button class="${k === cur ? "on" : ""}" data-tab="${k}">${icon(ic)}${l}</button>`).join("")}</nav>`;
}
const panicFab = () => `<button class="panic-fab" data-panic>${icon(I.bolt)} Хүсэл төрлөө · Тусламж</button>`;
function reasonsCard() {
  const r = pickList("reasons"); if (!r.length) return "";
  return `<div class="card" style="margin-top:10px"><h3>Таны шалтгаан</h3><div class="chips" style="margin-top:10px">${r.map((x) => `<span class="chip">${esc(x)}</span>`).join("")}</div></div>`;
}
function msgHTML(m, k) {
  if (m.role === "crisis") return crisisHTML();
  const cls = m.role === "user" ? "u" : "a";
  return `<div class="msg ${cls}">${esc(m.content)}${cls === "a" && S.voice && voiceAvailable ? `<br><button class="say" data-say="${k}">${icon(I.play, 13)} Сонсох <span class="wave idle"><b></b><b></b><b></b><b></b></span></button>` : ""}</div>`;
}
function crisisHTML() {
  return `<div class="card crisis"><div class="row" style="color:var(--rose)">${icon(I.life, 22)}<h3 style="color:var(--ink)">Та ганцаараа биш</h3></div>
    <p class="small" style="color:var(--ink);margin:8px 0 4px">Хэрэв өөрийгөө гэмтээх бодол төрж байвал яг одоо мэргэжлийн хүнтэй ярилцаарай. Үнэгүй, нууцлалтай.</p>
    ${CRISIS.map((c) => `<a class="tel" href="tel:${c.n.replace(/-/g, "")}"><b>${c.n}</b><span class="small">${c.t}</span></a>`).join("")}</div>`;
}
function greeting() { return `Сайн уу, ${S.name}. Би энд байна. Өнөөдөр сэтгэл санаа тань ямар байна? Юу ч хамаагүй ярьж болно.`; }
function nextLesson() { for (const c of COURSES) for (const l of c.lessons) if (!S.lessonsDone.includes(l.id)) return { c, l }; return null; }
function hasPlan() { return S.plan && (S.plan.paid || S.plan.trialEnds > Date.now()); }
function planLabel() {
  if (!S.plan) return ""; const p = PLANS.find((x) => x.id === S.plan.id);
  if (S.plan.paid) return `${p.t} · идэвхтэй`;
  return `Үнэгүй туршилт · ${Math.max(0, Math.ceil((S.plan.trialEnds - Date.now()) / DAY))} хоног үлдсэн`;
}

/* ---------- sheets & fullscreen ---------- */
function sheet(html, onMount) {
  closeSheet();
  const o = document.createElement("div"); o.className = "overlay"; o.id = "ov";
  o.innerHTML = `<div class="sheet" role="dialog"><div class="grab"></div>${html}</div>`;
  o.addEventListener("click", (e) => { if (e.target === o) closeSheet(); });
  document.body.appendChild(o); onMount && onMount(o);
}
function closeSheet() { document.getElementById("ov")?.remove(); }
function full(html, onMount, cls = "full") {
  closeFull();
  const o = document.createElement("div"); o.className = cls; o.id = "full"; o.innerHTML = html;
  document.body.appendChild(o); onMount && onMount(o);
}
function closeFull() { stopVoice(); clearTimeout(window.__bt); clearInterval(window.__ut); window.__panicOn = false; document.getElementById("full")?.remove(); }

/* ---------- AFTER hooks ---------- */
const AFTER = {
  splash: () => setTimeout(() => route.name === "splash" && go("intro"), 1500),
  welcome: () => prefetch([VO.privacy, VO.choose, VO.quiz]),
  name: () => {
    const inp = q("#nm"), b = q("#nmGo");
    inp.addEventListener("input", () => { b.disabled = !inp.value.trim(); });
    inp.addEventListener("keydown", (e) => { if (e.key === "Enter" && inp.value.trim()) b.click(); });
    b.onclick = () => { S.name = inp.value.trim().slice(0, 24); save(); prefetch([VOF.result(S.name), VOF.done(S.name)]); go("calc"); };
  },
  calc: () => {
    S.score = computeScore(); save();
    [0, 1, 2].forEach((k) => setTimeout(() => { const el = q(`[data-step="${k}"]`); if (el) el.style.opacity = 1; }, 900 + k * 1000));
    setTimeout(() => route.name === "calc" && go("result"), 4200);
  },
  result: () => {
    const arc = q("#garc"); requestAnimationFrame(() => (arc.style.strokeDashoffset = arc.dataset.off));
    let n = 0; const tgt = S.score; const t = setInterval(() => { n = Math.min(tgt, n + 2); const el = q("#gnum"); if (!el) return clearInterval(t); el.textContent = n; if (n >= tgt) clearInterval(t); }, 26);
  },
  commit: () => {
    const hold = q("#hold"), ring = q("#hring"); let t0 = 0, raf = 0, doneF = false;
    const step = () => {
      const p = Math.min(1, (Date.now() - t0) / 3000); ring.style.strokeDashoffset = 289 * (1 - p);
      if (p >= 1) { doneF = true; vibrate([30, 40, 80]); hold.classList.remove("holding"); q("#holdtxt").textContent = "Амлалт өгөгдлөө ✓"; S.committedAt = Date.now(); save(); confetti(); setTimeout(() => go("paywall"), 1200); return; }
      raf = requestAnimationFrame(step);
    };
    const start = (e) => { if (doneF) return; e.preventDefault(); t0 = Date.now(); hold.classList.add("holding"); vibrate(15); raf = requestAnimationFrame(step); };
    const end = () => { if (doneF) return; cancelAnimationFrame(raf); hold.classList.remove("holding"); ring.style.transition = "stroke-dashoffset .3s"; ring.style.strokeDashoffset = 289; setTimeout(() => (ring.style.transition = ""), 300); };
    hold.addEventListener("pointerdown", start); hold.addEventListener("pointerup", end); hold.addEventListener("pointerleave", end); hold.addEventListener("pointercancel", end);
  },
  companion: () => {
    q("#cSave").onclick = () => {
      const name = q("#cn").value.trim(), phone = q("#cp").value.trim();
      if (!name) return toast("Нэрийг нь бичнэ үү");
      S.companion = { name, phone }; save(); go(FLOW[FLOW.indexOf("companion") + 1]); inviteCompanion();
    };
  },
  done: () => {
    const now = Date.now(); S.habits.forEach((h) => { if (!S.start[h]) S.start[h] = now; }); S.onboarded = true; S.current = S.habits[0]; save();
    const t = setInterval(() => { const el = q("#dclock"); if (!el) return clearInterval(t); const s = Math.floor((Date.now() - now) / 1000); el.textContent = `00:${pad(Math.floor(s / 60))}:${pad(s % 60)}`; }, 1000);
    q("#enter").onclick = () => go("home");
    prefetch([VO.panic, VO.inhale, VO.hold, VO.exhale]);
  },
  home: () => {
    const tick = () => {
      const e = elapsed(S.current); const s = Math.floor(e / 1000); const el = q("#cclock"); if (!el) return;
      el.textContent = `${pad(Math.floor((s % 86400) / 3600))}:${pad(Math.floor((s % 3600) / 60))}:${pad(s % 60)}`;
      if (q("#cdays").textContent != Math.floor(e / DAY)) render();
    };
    tick(); ticker = setInterval(tick, 1000);
    checkMilestone();
    prefetch([dailyLine(), VO.panic, VO.inhale, VO.hold, VO.exhale]);
  },
  amin: () => {
    window.scrollTo(0, document.body.scrollHeight);
    q("#cform").onsubmit = (e) => { e.preventDefault(); const v = q("#cin").value.trim(); if (v) { q("#cin").value = ""; sendChat(v); } };
  },
};
function dailyLine() { return `${VOF.greet(S.name, daysOf(S.current || S.habits[0]))} ${QUOTES[new Date().getDate() % QUOTES.length]}`; }

/* ---------- events ---------- */
document.addEventListener("click", (e) => {
  const t = e.target.closest("button, a"); if (!t) return;
  const d = t.dataset;
  if (d.go) return go(d.go);
  if (d.next) return go(FLOW[FLOW.indexOf(d.next) + 1]);
  if (d.back !== undefined) {
    const BACK = { privacy: "welcome", choose: "privacy", quizIntro: "choose", safety: "quiz", name: "quiz", result: "name", roadmap: "result", commit: "roadmap", companion: "paywall", blocker: "companion" };
    const b = BACK[route.name] || "intro"; return go(b, b === "quiz" ? { i: quizList().length - 1 } : {});
  }
  if (d.replay !== undefined) { const l = lineFor(route.name, route.p); return l && narrate(l); }
  if (d.sound !== undefined) { S.voice = !S.voice; S.ambient = S.voice; save(); if (!S.voice) { stopVoice(); stopAmbient(); } else unlockAudio(); return render(); }
  if (d.habit) { const id = d.habit; S.habits = S.habits.includes(id) ? S.habits.filter((x) => x !== id) : [...S.habits, id]; save(); t.classList.toggle("on"); q("[data-next='choose']").disabled = !S.habits.length; return; }
  if (d.ans !== undefined) return answer(+d.q, +d.ans, t);
  if (d.qnext !== undefined) return quizNext(+d.qnext);
  if (d.qback !== undefined) { const i = +d.qback; return i > 0 ? go("quiz", { i: i - 1 }) : go("quizIntro"); }
  if (d.plan) { route.p.plan = d.plan; document.querySelectorAll("[data-plan]").forEach((b) => b.classList.toggle("on", b === t)); q("[data-pay]").dataset.pay = d.plan; return; }
  if (d.pay) return qpay(d.pay);
  if (d.skipPay !== undefined) return S.onboarded ? go("me") : go(FLOW[FLOW.indexOf("paywall") + 1]);
  if (d.btab) return go("blocker", { tab: d.btab });
  if (d.tab) return go(d.tab);
  if (d.cur) { S.current = d.cur; save(); return render(); }
  if (d.mood !== undefined) { S.checkins[today()] = { mood: +d.mood }; save(); toast("Хадгаллаа. Баярлалаа 🤍"); return render(); }
  if (d.daily !== undefined) { if (speaking) return stopVoice(); const pl = q("#dplay"); pl.innerHTML = icon(I.pause, 18); return speak(dailyLine(), { np: true }).then(() => { if (pl.isConnected) pl.innerHTML = icon(I.play, 18); }); }
  if (d.panic !== undefined) return panic();
  if (d.relapse !== undefined) return relapse();
  if (d.lesson) return openLesson(d.lesson);
  if (d.quick) return sendChat(d.quick);
  if (d.say !== undefined) return sayMsg(+d.say, t);
  if (d.autoplay !== undefined) { S.autoplay = !(S.autoplay && S.voice); if (S.autoplay) S.voice = true; save(); if (!S.autoplay) stopVoice(); toast(S.autoplay ? "Амин хариултаа чангаар уншина" : "Чангаар уншихыг унтраалаа"); return render(); }
  if (d.newnote !== undefined) return newNote();
  if (d.voice !== undefined) { S.voice = !S.voice; save(); if (!S.voice) stopVoice(); return render(); }
  if (d.ambient !== undefined) { S.ambient = !S.ambient; save(); S.ambient ? unlockAudio() : stopAmbient(); return render(); }
  if (d.autoplaySw !== undefined) { S.autoplay = !S.autoplay; save(); return render(); }
  if (d.sheet) return SHEETS[d.sheet]();
  if (d.wipe !== undefined) {
    return sheet(`<h2>Бүгдийг устгах уу?</h2><p class="small" style="margin-top:8px">Тоолуур, тэмдэглэл, Аминтай хийсэн яриа бүгд энэ утаснаас устана. Буцаах боломжгүй.</p>
      <div class="stack" style="margin-top:16px"><button class="btn rose" id="wy">Тийм, устга</button><button class="btn link" id="wn">Болих</button></div>`, (o) => {
      q("#wn", o).onclick = closeSheet;
      q("#wy", o).onclick = () => { try { localStorage.removeItem(KEY); } catch (e) {} S = blank(); closeSheet(); go("intro"); };
    });
  }
});

function answer(i, k, el) {
  const list = quizList(); const qq = list[i];
  if (qq.type === "multi") {
    const a = S.answers[qq.id] || []; S.answers[qq.id] = a.includes(k) ? a.filter((x) => x !== k) : [...a, k]; save();
    el.classList.toggle("on"); q("[data-qnext]").disabled = !S.answers[qq.id].length; return;
  }
  S.answers[qq.id] = k; save();
  document.querySelectorAll("[data-ans]").forEach((b) => b.classList.toggle("on", b === el)); vibrate(8);
  setTimeout(() => quizNext(i), 300);
}
function quizNext(i) {
  const list = quizList();
  if (i + 1 < list.length) return go("quiz", { i: i + 1 });
  return needsAlcoholSafety() ? go("safety") : go("name");
}

/* ---------- QPay (placeholder until merchant credentials) ---------- */
function qpay(planId) {
  const p = PLANS.find((x) => x.id === planId);
  sheet(`<div class="center"><h2>QPay-ээр төлөх</h2><p class="small" style="margin-top:6px">${p.t} · ${fmtMNT(p.p)}, эхний 3 хоногийн дараа</p>
    <div class="qr">${fakeQR()}</div><p class="small">Банкны аппаараа QR кодыг уншуулна уу.</p>
    <div class="card" style="margin-top:14px;text-align:left"><p class="small" style="margin:0">Туршилтын хувилбар: QPay холболт хараахан идэвхжээгүй тул төлбөр авахгүй. Үнэгүй туршилтаар шууд үргэлжлүүлж болно.</p></div>
    <div class="stack" style="margin-top:16px"><button class="btn" id="trial">Үнэгүй туршилт эхлүүлэх</button><button class="btn link" id="cancel">Болих</button></div></div>`, (o) => {
    q("#trial", o).onclick = () => { S.plan = { id: planId, trialEnds: Date.now() + 3 * DAY, paid: false }; save(); closeSheet(); toast("Pro идэвхжлээ ✨"); S.onboarded ? go("home") : go(FLOW[FLOW.indexOf("paywall") + 1]); };
    q("#cancel", o).onclick = closeSheet;
  });
}
function fakeQR() {
  let s = '<svg viewBox="0 0 29 29" width="100%" height="100%" shape-rendering="crispEdges">'; let seed = 7;
  const rnd = () => ((seed = (seed * 9301 + 49297) % 233280) / 233280);
  for (let y = 0; y < 29; y++) for (let x = 0; x < 29; x++) {
    const f = (x < 7 && y < 7) || (x > 21 && y < 7) || (x < 7 && y > 21);
    if (f) { const lx = x > 21 ? x - 22 : x, ly = y > 21 ? y - 22 : y; if (lx === 0 || ly === 0 || lx === 6 || ly === 6 || (lx > 1 && lx < 5 && ly > 1 && ly < 5)) s += `<rect x="${x}" y="${y}" width="1" height="1" fill="#070B1E"/>`; }
    else if (rnd() > 0.52) s += `<rect x="${x}" y="${y}" width="1" height="1" fill="#070B1E"/>`;
  }
  return s + "</svg>";
}

/* ---------- companion ---------- */
function inviteCompanion() {
  if (!S.companion?.phone) return;
  const body = encodeURIComponent("Сайн уу! Би нэг зуршлаасаа ангижрахаар шийдлээ. Хэцүү үед чамд хандаж болох уу? Чамайг дэмжээд байвал надад их тус болно 🤍");
  sheet(`<h2>${esc(S.companion.name)}-д мэдэгдэх үү?</h2><p class="small" style="margin-top:8px">Таны утаснаас бэлэн мессеж нээгдэнэ. Илгээх эсэхээ та шийднэ.</p>
    <div class="stack" style="margin-top:16px"><a class="btn" href="sms:${esc(S.companion.phone)}?&body=${body}" id="smsGo">Мессеж бичих</a><button class="btn link" id="smsX">Дараа</button></div>`,
    (o) => { q("#smsGo", o).addEventListener("click", () => setTimeout(closeSheet, 300)); q("#smsX", o).onclick = closeSheet; });
}

/* ---------- panic: Amin talks you through it ---------- */
function panic() {
  vibrate(20);
  const reasons = pickList("reasons");
  full(`<div class="inner-col"><div class="screen">
    <div class="top"><button class="iconbtn" id="pX" aria-label="Хаах">${icon(I.close, 20)}</button><div class="grow"></div><span class="small" id="round" style="font-variant-numeric:tabular-nums"></span></div>
    <div class="center" style="margin-top:6px"><div class="eyebrow" style="color:var(--mint)">Яаралтай тусламж</div><h2 style="margin-top:8px">Надтай хамт амьсгалъя</h2></div>
    <div class="breath"><div class="halo"></div><div class="halo2"></div><div class="b" id="bb"></div><div class="lbl" id="bl">Амин</div></div>
    <div class="row" style="gap:10px;align-items:flex-start;justify-content:center"><div class="orb-mini" id="porb" style="width:30px;height:30px"></div><div class="caption sm left" id="pcap" style="max-width:320px"></div></div>
    <div id="after" hidden style="margin-top:16px"><div class="stack">
      ${reasons.length ? `<div class="card"><h3>Та яагаад эхэлсэн бэ</h3><div class="chips" style="margin-top:10px">${reasons.map((r) => `<span class="chip">${esc(r)}</span>`).join("")}</div></div>` : ""}
      <div class="card"><h3>Хүсэл бол давалгаа</h3><p class="small" style="margin:6px 0 10px">Ихэнх хүсэл 15–30 минутад суларна. 10 минут хүлээгээд үзэх үү?</p>
        <button class="btn ghost sm" id="surf" style="width:100%;font-variant-numeric:tabular-nums">10 минутын таймер</button></div>
      <div class="card"><h3>Одоо хийж болох зүйл</h3><div class="small" style="margin-top:6px;line-height:1.9">🚶 Гадаа 10 минут алх · 🚿 Хүйтэн ус нүүрэндээ цац · 📵 Утсаа өөр өрөөнд тавь · 💧 Нэг аяга ус уу · 🙌 20 суулт хий</div></div>
      ${S.companion?.phone ? `<a class="btn ghost" href="tel:${esc(S.companion.phone)}">${icon(I.phone, 18)} ${esc(S.companion.name)} · ${esc(S.companion.phone)}</a>` : ""}
      <button class="btn ghost" id="pChat">${icon(I.chat, 18)} Аминтай ярих</button>
      <div class="card"><h3 class="center">Хүсэл буурсан уу?</h3><div class="row" style="margin-top:12px"><button class="btn" id="won">Тийм, би ялсан</button></div>
        <button class="btn link" id="notyet" style="width:100%">Одоохондоо үгүй</button></div>
      <button class="btn link" id="pCrisis" style="font-size:13px">Аюулгүй байдлын утас</button>
    </div></div></div></div>`, async (o) => {
    window.__panicOn = true;
    q("#pX", o).onclick = closeFull;
    const bb = q("#bb", o), bl = q("#bl", o), rd = q("#round", o), porb = q("#porb", o), pcap = q("#pcap", o);
    const showAfter = () => { const a = q("#after", o); if (a) a.hidden = false; };
    setTimeout(showAfter, 5000); // help is never locked behind the exercise
    q("#won", o).onclick = () => { S.urges.push({ ts: Date.now(), h: S.current, resisted: true }); save(); confetti(); window.__panicOn = false; speak(VO.won, { capEl: pcap, orbEl: porb }); setTimeout(() => { closeFull(); toast("Та давалгааг даван туллаа 💪"); render(); }, 3600); };
    q("#notyet", o).onclick = () => { closeFull(); go("amin"); setTimeout(() => sendChat("Яг одоо хүсэл маш хүчтэй байна. Туслаач."), 200); };
    q("#pChat", o).onclick = () => { closeFull(); go("amin"); };
    q("#pCrisis", o).onclick = () => SHEETS.crisis();
    q("#surf", o).onclick = (ev) => {
      let left = 600; const b = ev.currentTarget; clearInterval(window.__ut); speak(VO.surf, { capEl: pcap, orbEl: porb });
      window.__ut = setInterval(() => { left--; b.textContent = `${pad(Math.floor(left / 60))}:${pad(left % 60)} · давалгаа буурч байна`; if (left <= 0) { clearInterval(window.__ut); b.textContent = "10 минут өнгөрлөө. Та чадлаа!"; vibrate([40, 60, 40]); speak(VO.surfDone, { capEl: pcap, orbEl: porb }); } }, 1000);
    };
    // 1) Amin's calming intro, 2) four guided breaths with spoken cues
    await speak(VO.panic, { capEl: pcap, orbEl: porb });
    if (!window.__panicOn) return;
    const phases = [["Амьсгал ав", 4000, 1.9, VO.inhale], ["Барь", 4000, 1.9, VO.hold], ["Гарга", 6000, 1, VO.exhale]];
    const ROUNDS = 4;
    for (let r = 1; r <= ROUNDS && window.__panicOn; r++) {
      rd.textContent = `${r}/${ROUNDS}`;
      for (const [lbl, ms, sc, cue] of phases) {
        if (!window.__panicOn) return;
        bl.textContent = lbl; bb.style.transitionDuration = ms + "ms"; bb.style.transform = `scale(${sc})`; vibrate(8);
        if (r <= 2) speak(cue, { orbEl: porb }); // spoken cues for the first two rounds, then quiet breathing
        await new Promise((res) => (window.__bt = setTimeout(res, ms)));
      }
    }
    if (!window.__panicOn) return;
    bl.textContent = "Сайн байна"; showAfter();
    speak(VO.breathDone, { capEl: pcap, orbEl: porb });
  });
}

/* ---------- relapse ---------- */
function relapse() {
  const trig = QUIZ.find((x) => x.id === "triggers").opts.map((o) => o[0]);
  let pick = S.current, why = [];
  sheet(`<div class="center"><div class="orb-mini" id="rorb" style="margin:0 auto 12px;width:56px;height:56px"></div><h2>Зүгээр ээ</h2></div>
    <div class="caption sm" id="rcap" style="margin-top:8px"></div>
    ${S.habits.length > 1 ? `<h3 style="margin-top:6px">Аль нь?</h3><div class="chips" style="margin-top:8px">${S.habits.map((h) => `<button class="chip ${h === pick ? "on" : ""}" data-rh="${h}">${H(h).label}</button>`).join("")}</div>` : ""}
    <h3 style="margin-top:16px">Юу өдөөсөн бэ?</h3><div class="chips" style="margin-top:8px">${trig.map((t) => `<button class="chip" data-rt="${esc(t)}">${t}</button>`).join("")}</div>
    <textarea class="field" id="rn" style="margin-top:14px;min-height:80px" placeholder="Юу болсныг товч бичих (заавал биш)"></textarea>
    <div class="stack" style="margin-top:16px"><button class="btn" id="rgo">Дахин эхлэх</button><button class="btn link" id="rx">Болих</button></div>`, (o) => {
    speak(VO.relapse, { capEl: q("#rcap", o), orbEl: q("#rorb", o) });
    o.addEventListener("click", (e) => {
      const b = e.target.closest("[data-rh],[data-rt]"); if (!b) return; e.stopPropagation();
      if (b.dataset.rh) { pick = b.dataset.rh; o.querySelectorAll("[data-rh]").forEach((x) => x.classList.toggle("on", x === b)); }
      if (b.dataset.rt) { const v = b.dataset.rt; why = why.includes(v) ? why.filter((x) => x !== v) : [...why, v]; b.classList.toggle("on"); }
    }, true);
    q("#rx", o).onclick = () => { stopVoice(); closeSheet(); };
    q("#rgo", o).onclick = () => {
      const e = elapsed(pick); const note = q("#rn", o).value.trim().slice(0, 600);
      S.best[pick] = Math.max(S.best[pick] || 0, e); S.cleanTotal[pick] = (S.cleanTotal[pick] || 0) + e;
      S.relapses.push({ ts: Date.now(), h: pick, trig: why, note });
      if (note) S.journal.push({ ts: Date.now(), mood: 1, tag: "Бүдрэл", text: note });
      S.start[pick] = Date.now(); S.celebrated[pick] = []; save(); stopVoice(); closeSheet();
      toast("Шинэ эхлэл. Та энд байгаа нь чухал."); render();
    };
  });
}

/* ---------- milestones ---------- */
function checkMilestone() {
  const h = S.current; const d = daysOf(h); const m = prevMilestone(d);
  S.celebrated[h] = S.celebrated[h] || [];
  if (m > 0 && !S.celebrated[h].includes(m)) {
    S.celebrated[h].push(m); save(); confetti();
    sheet(`<div class="center"><div class="orb-wrap" id="morb" style="width:130px;height:130px;margin:0 auto"><div class="orb-glow"></div><div class="orb-ring"></div><div class="orb" style="width:78px;height:78px"></div></div>
      <div class="eyebrow">Шинэ босго</div><h1 style="margin-top:10px;font-size:64px;font-weight:300">${m}</h1><h2>өдөр!</h2>
      <div class="caption sm" id="mcap" style="margin-top:10px"></div>
      <div class="stack" style="margin-top:14px"><button class="btn" id="mok">Баярлалаа</button></div></div>`, (o) => {
      speak(VOF.milestone(S.name, m), { capEl: q("#mcap", o), orbEl: q("#morb", o) });
      q("#mok", o).onclick = () => { stopVoice(); closeSheet(); };
    });
  }
}

/* ---------- lessons: story mode, narrated, auto-advancing ---------- */
function openLesson(ref) {
  const [cid, lid] = ref.split(":"); const ci = COURSES.findIndex((c) => c.id === cid); const c = COURSES[ci]; const l = c.lessons.find((x) => x.id === lid);
  if (ci > 0 && !hasPlan()) return go("paywall");
  let i = 0, paused = false; const N = l.slides.length; let token = 0;
  full(`<div class="col">
      <div class="segs" id="segs">${[...Array(N + 1)].map(() => `<i><b></b></i>`).join("")}</div>
      <div class="top" style="margin-top:10px"><div class="orb-mini" id="lorb" style="width:32px;height:32px"></div><div class="grow"><div class="small" style="font-weight:800;color:var(--ink)">${esc(l.t)}</div><div class="small">${esc(c.title)}</div></div>
        <button class="iconbtn ctrl" id="lpp" aria-label="Зогсоох">${icon(I.pause, 16)}</button><button class="iconbtn ctrl" id="lx" aria-label="Хаах">${icon(I.close, 18)}</button></div>
      <button class="tapl" id="tl" aria-label="Өмнөх"></button><button class="tapr" id="tr" aria-label="Дараах"></button>
      <div class="body" id="lbody"></div>
      <div class="ctrl" id="lfoot"></div></div>`, (o) => {
    o.style.setProperty("--sc", c.color + "55");
    const segs = [...o.querySelectorAll("#segs i")];
    const setSeg = (k, f) => segs.forEach((s, j) => { s.querySelector("b").style.width = j < k ? "100%" : j === k ? `${Math.round(f * 100)}%` : "0"; });
    const pp = q("#lpp", o);
    const draw = async () => {
      const my = ++token; paused = false; pp.innerHTML = icon(I.pause, 16);
      const last = i === N; setSeg(i, 0);
      if (last) {
        q("#lbody", o).innerHTML = `<div class="eyebrow" style="color:${c.color}">Эргэцүүлэл</div><h2 style="font-weight:300">${esc(l.reflect)}</h2>
          <div class="caption sm left" id="lcap" style="min-height:0;color:var(--muted)"></div><textarea class="field" id="lr" placeholder="Энд бичээрэй…"></textarea>`;
        q("#lfoot", o).innerHTML = `<button class="btn" id="lfin">Хадгалаад дуусгах</button>`;
        q("#tr", o).hidden = true;
        q("#lfin", o).onclick = finish;
        setSeg(i, 1);
        await speak(`${l.reflect} ${VO.reflect}`, { capEl: q("#lcap", o), orbEl: q("#lorb", o) });
        return;
      }
      q("#tr", o).hidden = false;
      q("#lbody", o).innerHTML = `<div class="eyebrow" style="color:${c.color}">${i + 1} / ${N}</div><p class="slide" id="lcap"></p>`;
      q("#lfoot", o).innerHTML = `<p class="small center" style="margin:0">Дэлгэцийн баруун талд дарж урагшлах · зүүн талд буцах</p>`;
      const ok = await speak(l.slides[i], { capEl: q("#lcap", o), orbEl: q("#lorb", o), onProgress: (f) => setSeg(i, f) });
      if (ok && my === token && !paused) { await sleep(900); if (my === token && !paused && i < N) { i++; draw(); } }
    };
    const finish = () => {
      const txt = q("#lr", o)?.value.trim();
      if (txt) S.journal.push({ ts: Date.now(), mood: 3, tag: "Хичээл", q: l.reflect, text: txt });
      if (!S.lessonsDone.includes(l.id)) S.lessonsDone.push(l.id);
      save(); confetti(); speak(VO.lessonDone, { np: true }); document.getElementById("full")?.remove(); toast("Хичээл дууслаа ✓"); render();
    };
    q("#lx", o).onclick = () => { token++; closeFull(); };
    q("#tl", o).onclick = () => { if (i > 0) { stopVoice(); i--; draw(); } };
    q("#tr", o).onclick = () => { if (i < N) { stopVoice(); i++; draw(); } };
    pp.onclick = () => {
      if (!paused) { paused = true; token++; stopVoice(); pp.innerHTML = icon(I.play, 16); const cap = q("#lcap", o); cap && cap.querySelectorAll(".w").forEach((w) => w.classList.add("on")); }
      else draw();
    };
    prefetch(l.slides.concat([`${l.reflect} ${VO.reflect}`, VO.lessonDone]));
    draw();
  }, "story");
}

/* ---------- journal ---------- */
function newNote() {
  let mood = 2;
  sheet(`<h2>Шинэ тэмдэглэл</h2><div class="moods">${["😣", "😔", "😐", "🙂", "😄"].map((m, k) => `<button class="mood ${k === 2 ? "on" : ""}" data-nm="${k}">${m}</button>`).join("")}</div>
    <textarea class="field" id="nt" style="margin-top:14px" placeholder="Өнөөдөр юу мэдэрсэн бэ? Ямар хүсэл төрсөн бэ, яаж даван туулсан бэ?"></textarea>
    <div class="stack" style="margin-top:14px"><button class="btn" id="ns">Хадгалах</button></div>`, (o) => {
    o.addEventListener("click", (e) => { const b = e.target.closest("[data-nm]"); if (!b) return; e.stopPropagation(); mood = +b.dataset.nm; o.querySelectorAll("[data-nm]").forEach((x) => x.classList.toggle("on", x === b)); }, true);
    q("#ns", o).onclick = () => { const t = q("#nt", o).value.trim(); if (!t) return toast("Юм бичнэ үү"); S.journal.push({ ts: Date.now(), mood, text: t.slice(0, 3000) }); save(); closeSheet(); render(); };
  });
}

/* ---------- chat with Amin ---------- */
let sending = false;
const OFFLINE = [
  "Би энд байна. Яг одоо гурван удаа удаан амьсгалаад үзээрэй. Дөрвөн секунд авч, зургаан секунд гаргана. Дараа нь юу мэдэрч байгаагаа надад хэлээрэй.",
  "Энэ мэдрэмж түр зуурынх. Хүсэл бол давалгаа, тэр өсөөд буурдаг. Улаан Тусламж товчийг дараад надтай хамт амьсгалъя.",
  "Та энд ирж надад бичсэн нь аль хэдийн зөв алхам. Одоо өөрийгөө өөр орчинд аваачиж болох уу? Гадаа гарах, эсвэл өөр өрөөнд орох.",
];
function sayMsg(k, btn) {
  const m = S.chat[k] || { content: greeting() };
  if (speaking && btn.classList.contains("playing")) { stopVoice(); return; }
  document.querySelectorAll(".say.playing").forEach((b) => b.classList.remove("playing"));
  btn.classList.add("playing"); const w = btn.querySelector(".wave"); w && w.classList.remove("idle");
  speak(m.content, { orbEl: q("#aorb"), cacheable: !S.chat[k] }).then(() => { btn.classList.remove("playing"); w && w.classList.add("idle"); });
}
async function sendChat(text) {
  if (sending) return;
  if (route.name !== "amin") go("amin");
  const d = today(); if (S.chatDay.d !== d) S.chatDay = { d, n: 0 };
  const isCrisis = CRISIS_WORDS.some((w) => text.toLowerCase().includes(w));
  if (!hasPlan() && S.chatDay.n >= FREE_CHATS && !isCrisis) {
    return sheet(`<div class="center"><div class="orb-mini" style="margin:0 auto 12px;width:56px;height:56px"></div><h2>Өнөөдрийн үнэгүй яриа дууслаа</h2>
      <p class="lead" style="font-size:15px">Аминтай хязгааргүй ярихын тулд Pro болоорой. Яаралтай тусламж, амьсгалын дасгал үргэлж үнэгүй.</p>
      <div class="stack" style="margin-top:16px"><button class="btn" data-go="paywall">Pro болох</button><button class="btn ghost" data-panic>Амьсгалын дасгал</button></div></div>`);
  }
  S.chat.push({ role: "user", content: text });
  if (isCrisis) S.chat.push({ role: "crisis", content: "" });
  S.chatDay.n++; save(); render();
  q("#chat").insertAdjacentHTML("beforeend", `<div class="msg a typing" id="typing"><span></span><span></span><span></span></div>`);
  window.scrollTo(0, document.body.scrollHeight);
  sending = true;
  const h = S.current || S.habits[0];
  const turns = S.chat.filter((m) => m.role !== "crisis").slice(-16);
  while (turns.length && turns[0].role !== "user") turns.shift();
  const profile = { name: S.name, habits: S.habits.map((x) => H(x).label), days: h ? daysOf(h) : 0, triggers: pickList("triggers"), reasons: pickList("reasons"), goal: goalText() };
  let reply = null;
  try {
    if (PREVIEW) {
      const sample = window.claude ? await window.claude.use("sample") : null;
      if (!sample) throw new Error("no sample");
      const ctxText = `${RULES}\n\nНэр: ${profile.name}\nАнгижрах зүйлс: ${profile.habits.join(", ")}\nЦэвэр өдөр: ${profile.days}\nӨдөөгчид: ${profile.triggers.join(", ") || "—"}\nШалтгаан: ${profile.reasons.join(", ") || "—"}\nЗорилго: ${profile.goal || "—"}`;
      reply = (await sample([{ role: "user", content: ctxText }, ...turns], { cache: false })).text.trim();
    } else {
      const res = await fetch("/api/coach", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ messages: turns, profile }) });
      reply = (await res.json()).reply;
    }
  } catch (e) { reply = null; }
  if (!reply) reply = OFFLINE[S.chat.length % OFFLINE.length];
  sending = false;
  S.chat.push({ role: "assistant", content: reply }); S.chat = S.chat.slice(-60); save();
  if (route.name === "amin") {
    render(); window.scrollTo(0, document.body.scrollHeight);
    if (S.voice && S.autoplay && voiceAvailable) { const btns = document.querySelectorAll(".say"); const last = btns[btns.length - 1]; last && sayMsg(S.chat.length - 1, last); }
  }
}

/* ---------- profile sheets ---------- */
const SHEETS = {
  crisis: () => sheet(`<h2>Яаралтай тусламж</h2><p class="small" style="margin-top:6px">Хэрэв та эсвэл хэн нэгэн аюулд байвал яг одоо залгаарай.</p>
    <div style="margin-top:10px">${CRISIS.map((c) => `<a class="tel" href="tel:${c.n.replace(/-/g, "")}"><b>${c.n}</b><span class="small">${c.t}</span></a>`).join("")}</div>`),
  block: () => { const hs = S.habits.filter((h) => BLOCK[h]);
    sheet(`<h2>Хаах заавар</h2>${hs.map((h) => `<div class="card" style="margin-top:12px"><h3>${BLOCK[h].t}</h3>${BLOCK[h].steps.map(([k, v]) => `<div style="margin-top:10px"><div class="eyebrow" style="color:var(--mint)">${k}</div><div class="small" style="color:var(--ink);margin-top:3px">${esc(v)}</div></div>`).join("")}</div>`).join("")}`); },
  companion: () => sheet(`<h2>Итгэлт хүн</h2><div class="stack" style="margin-top:14px">
      <input class="field" id="cn" placeholder="Нэр" maxlength="30" value="${esc(S.companion?.name || "")}">
      <input class="field" id="cp" placeholder="Утас" inputmode="tel" maxlength="20" value="${esc(S.companion?.phone || "")}">
      <button class="btn" id="cs">Хадгалах</button>${S.companion ? `<button class="btn link" id="cdel" style="color:var(--rose)">Хасах</button>` : ""}</div>`, (o) => {
      q("#cs", o).onclick = () => { const n = q("#cn", o).value.trim(); if (!n) return toast("Нэр бичнэ үү"); S.companion = { name: n, phone: q("#cp", o).value.trim() }; save(); closeSheet(); render(); inviteCompanion(); };
      const del = q("#cdel", o); if (del) del.onclick = () => { S.companion = null; save(); closeSheet(); render(); };
    }),
  habits: () => sheet(`<h2>Миний зуршлууд</h2><p class="small" style="margin-top:6px">Шинэ зуршил нэмбэл тоолуур нь одоогоос эхэлнэ.</p>
    <div class="stack" style="margin-top:14px">${HABITS.map((h) => `<button class="opt ${S.habits.includes(h.id) ? "on" : ""}" data-mh="${h.id}"><span class="ic" style="background:${h.hue}22;color:${h.hue}">${icon(h.icon)}</span>${h.label}<span class="chk"></span></button>`).join("")}</div>
    <button class="btn" id="mhs" style="margin-top:14px">Хадгалах</button>`, (o) => {
    let sel = [...S.habits];
    o.addEventListener("click", (e) => { const b = e.target.closest("[data-mh]"); if (!b) return; e.stopPropagation(); const id = b.dataset.mh;
      if (sel.includes(id) && sel.length === 1) return toast("Дор хаяж нэгийг үлдээнэ үү");
      if (!sel.includes(id) && sel.length >= 1 && !hasPlan()) return toast("Олон зуршил хянах нь Pro боломж");
      sel = sel.includes(id) ? sel.filter((x) => x !== id) : [...sel, id]; b.classList.toggle("on"); }, true);
    q("#mhs", o).onclick = () => { sel.forEach((h) => { if (!S.start[h]) S.start[h] = Date.now(); }); S.habits = sel; if (!sel.includes(S.current)) S.current = sel[0]; save(); closeSheet(); render(); };
  }),
};

/* ---------- boot ---------- */
document.addEventListener("visibilitychange", () => { if (!document.hidden && route.name === "home") render(); });
render();
})();
