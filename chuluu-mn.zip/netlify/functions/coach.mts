import type { Config } from "@netlify/functions";
import Anthropic from "@anthropic-ai/sdk";

const SYSTEM = `Чи бол "Амин" — "Чөлөө" апп-ын зөөлөн, тайван, дулаахан AI дасгалжуулагч. Хэрэглэгчид архи, насанд хүрэгчдийн контент (порно), видео тоглоом, мөрийтэй тоглоом, тамхи/вейп, утас/сошиал медиа зэрэг хамаарлаас ангижрахад тусалдаг.

ЯРИХ ХЭВ МАЯГ:
- Үргэлж монгол хэлээр (кирилл) хариул. Хэрэглэгчийг "та" гэж хүндэтгэлтэй ч дотно байдлаар хандана.
- Богино, 2–5 өгүүлбэр. Таны хариултыг Аминий дуу хоолойгоор чангаар уншина — тиймээс ярианы хэлээр, жагсаалт, гарчиг, тэмдэг, emoji огт бүү ашигла. Тоог үгээр бич (жишээ: "арван минут").
- Хэзээ ч шүүмжлэхгүй, ичээхгүй, айлгахгүй. Бүдэрсэн (relapse) бол энэ нь бүтэлгүйтэл биш, суралцах мэдээлэл гэж тайлбарла.
- Танин мэдэхүйн зан үйлийн арга (CBT), сэдэл нэмэгдүүлэх ярилцлага (MI), "хүслийн давалгаан дээр гулгах" (urge surfing), амьсгалын дасгал, өдөөгчийг таних, орлуулах зуршил зэрэг нотолгоонд суурилсан аргыг энгийн үгээр ашигла.
- Нэг удаад нэг жижиг, одоо хийж болох алхам санал болго. Дараа нь нэг асуулт асууж яриаг үргэлжлүүл.

АЮУЛГҮЙ БАЙДАЛ (заавал):
- Чи эмч, сэтгэл засалч биш. Онош тавихгүй, эмийн тун хэлэхгүй.
- Архи: удаан хугацаанд их хэмжээгээр, өдөр бүр уудаг хүн гэнэт зогсоох нь аюултай (чичрэх, таталт, дэмийрэл) байж болно. Ийм шинж (өглөө чичрэх, хөлрөх, уухгүй бол тэсэхгүй) дурдвал эмчид хандахыг тодорхой зөвлө, яаралтай үед 103.
- Амиа хорлох, өөрийгөө гэмтээх, бусдад хор хүргэх тухай дурдвал: тайван, халуун дулаан хандаж, ганцаараа биш гэдгийг хэл, Сэтгэцийн эрүүл мэндийн 24/7 үнэгүй утас 1800-2000, яаралтай үед 103 (түргэн тусламж) эсвэл 102 руу залгахыг санал болго. Ойр байгаа итгэлтэй хүнтэйгээ ярихыг уриал.
- Хүүхэдтэй холбоотой бэлгийн агуулга, хууль бус зүйлд хэзээ ч туслахгүй.
- Мөрийтэй тоглоомоос болж өрөнд орсон бол мөнгөө хамгаалах энгийн алхам (картаа итгэлтэй хүнд даатгах, банкнаас мөрийтэй гүйлгээ хаалгах) санал болго.

Хэрэглэгчийн мэдээлэл (байвал) доор өгөгдөнө. Үүнийг байгалийн байдлаар ашигла, бүгдийг нь давтаж бүү хэл.`;

export default async (req: Request) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  let body: any;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "bad_json" }, { status: 400 });
  }

  const messages = Array.isArray(body?.messages) ? body.messages : [];
  const clean = messages
    .filter((m: any) => (m?.role === "user" || m?.role === "assistant") && typeof m?.content === "string")
    .slice(-16)
    .map((m: any) => ({ role: m.role, content: m.content.slice(0, 2000) }));

  // Conversation must start with a user turn
  while (clean.length && clean[0].role !== "user") clean.shift();
  if (!clean.length) return Response.json({ error: "no_messages" }, { status: 400 });

  const p = body?.profile ?? {};
  const profileText = [
    p.name ? `Нэр: ${String(p.name).slice(0, 40)}` : "",
    Array.isArray(p.habits) && p.habits.length ? `Ангижрах зүйлс: ${p.habits.join(", ")}` : "",
    p.days != null ? `Цэвэр өдөр: ${p.days}` : "",
    Array.isArray(p.triggers) && p.triggers.length ? `Өдөөгчид: ${p.triggers.join(", ")}` : "",
    Array.isArray(p.reasons) && p.reasons.length ? `Болих шалтгаан: ${p.reasons.join(", ")}` : "",
    p.goal ? `Зорилго: ${p.goal}` : "",
  ]
    .filter(Boolean)
    .join("\n");

  if (!process.env.ANTHROPIC_BASE_URL && !process.env.ANTHROPIC_API_KEY) {
    return Response.json({ error: "ai_not_ready" }, { status: 503 });
  }

  try {
    const anthropic = new Anthropic();
    const msg = await anthropic.messages.create({
      model: Netlify.env.get("COACH_MODEL") || "claude-sonnet-4-5-20250929",
      max_tokens: 500,
      system: SYSTEM + (profileText ? `\n\n${profileText}` : ""),
      messages: clean,
    });
    const text = msg.content
      .filter((c: any) => c.type === "text")
      .map((c: any) => c.text)
      .join("\n")
      .trim();
    return Response.json({ reply: text });
  } catch (e) {
    console.error("coach error", e);
    return Response.json({ error: "ai_failed" }, { status: 502 });
  }
};

export const config: Config = {
  path: "/api/coach",
  method: ["POST"],
  rateLimit: { windowLimit: 30, windowSize: 60, aggregateBy: ["ip", "domain"] },
};
