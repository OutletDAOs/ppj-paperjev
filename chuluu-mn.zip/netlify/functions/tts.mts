import type { Config } from "@netlify/functions";

// Amin's voice via ElevenLabs.
// GET  /api/tts?v=2&t=<text>  -> cached on Netlify's CDN for a year (fixed narration lines)
// POST /api/tts {text}        -> uncached (Amin's live chat replies)
// Env (Site configuration → Environment variables, scope: Functions):
//   ELEVENLABS_API_KEY   required
//   AMIN_VOICE_ID        required — Amin's cloned voice
//   ELEVEN_MODEL         optional, default "eleven_v3"
//   AMIN_STYLE           optional v3 audio tag(s) put before each line, default "[calm] [softly]"; set "none" to disable

function clean(text: string) {
  return text
    .replace(/\p{Extended_Pictographic}|️/gu, "")
    .replace(/[*_#`>]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 900);
}

async function synth(raw: string) {
  const key = Netlify.env.get("ELEVENLABS_API_KEY");
  const voice = Netlify.env.get("AMIN_VOICE_ID");
  if (!key || !voice) return null;

  const model = Netlify.env.get("ELEVEN_MODEL") || "eleven_v3";
  const isV3 = model.includes("v3");
  const style = Netlify.env.get("AMIN_STYLE") ?? "[calm] [softly]";
  const text = isV3 && style !== "none" ? `${style} ${raw}` : raw;

  // eleven_v3 only accepts stability 0 / 0.5 / 1 and ignores most other settings.
  const voice_settings = isV3
    ? { stability: 0.5, similarity_boost: 0.85 }
    : { stability: 0.62, similarity_boost: 0.85, style: 0.12, use_speaker_boost: true, speed: 0.92 };

  const r = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voice}?output_format=mp3_44100_128`, {
    method: "POST",
    headers: { "xi-api-key": key, "Content-Type": "application/json", Accept: "audio/mpeg" },
    body: JSON.stringify({ text, model_id: model, voice_settings }),
  });
  if (!r.ok) {
    console.error("elevenlabs", r.status, (await r.text().catch(() => "")).slice(0, 400));
    return "error";
  }
  return await r.arrayBuffer();
}

export default async (req: Request) => {
  let text = "";
  if (req.method === "GET") {
    text = new URL(req.url).searchParams.get("t") || "";
  } else {
    try {
      text = (await req.json())?.text || "";
    } catch {}
  }
  text = clean(text);
  if (!text) return Response.json({ error: "no_text" }, { status: 400 });

  const audio = await synth(text);
  if (audio === null) return Response.json({ error: "voice_not_configured" }, { status: 503 });
  if (audio === "error") return Response.json({ error: "voice_failed" }, { status: 502 });

  const headers: Record<string, string> = { "Content-Type": "audio/mpeg" };
  if (req.method === "GET") {
    headers["Netlify-CDN-Cache-Control"] = "public, durable, s-maxage=31536000";
    headers["Netlify-Vary"] = "query=t|v";
    headers["Cache-Control"] = "public, max-age=604800";
  }
  return new Response(audio, { headers });
};

export const config: Config = {
  path: "/api/tts",
  method: ["GET", "POST"],
  rateLimit: { windowLimit: 90, windowSize: 60, aggregateBy: ["ip", "domain"] },
};
